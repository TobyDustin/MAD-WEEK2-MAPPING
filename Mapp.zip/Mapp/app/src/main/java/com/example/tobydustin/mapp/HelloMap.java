package com.example.tobydustin.mapp;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;




public class HelloMap extends AppCompatActivity implements View.OnClickListener {



        MapView mv;

        /** Called when the activity is first created. */
        @Override
        public void onCreate(Bundle savedInstanceState)
        {

            super.onCreate(savedInstanceState);

            // This line sets the user agent, a requirement to download OSM maps
            Configuration.getInstance().load(this, PreferenceManager.getDefaultSharedPreferences(this));
            setContentView(R.layout.activity_hello_map);

            mv = (MapView)findViewById(R.id.map1);

            mv.setBuiltInZoomControls(true);
            mv.setMultiTouchControls(true);
            mv.setMinZoomLevel(5);
            mv.setMaxZoomLevel(30);
            mv.getController().setZoom(11);
            mv.getController().setCenter(new GeoPoint(50.9099,-1.4092));
        }

        public boolean onCreateOptionsMenu(Menu menu)
        {

            Button search = (Button)findViewById(R.id.btnsearch);
            search.setOnClickListener(this);

            MenuInflater inflater=getMenuInflater();
            inflater.inflate(R.menu.menu_mapp, menu);
            return true;

        }


        public boolean onOptionsItemSelected(MenuItem item)
        {
            if(item.getItemId() == R.id.choosemap)
            {
                // react to the menu item being selected ...
                Intent intent = new Intent(this,MapChooseActivity.class);
                startActivityForResult(intent,0);

                return true;

            }else{
                return false;
            }
        }

    public void onClick(View v)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.error).setPositiveButton("OK",null);

        EditText longitude  = (EditText) findViewById(R.id.longitude);
        EditText latitude = (EditText) findViewById(R.id.latitude);
        double lo = Double.parseDouble(longitude.getText().toString());
        double lat = Double.parseDouble(latitude.getText().toString());
        if ((lo>180)|| (lo<-180)) {
            builder.show();
            mv.getController().setCenter(new GeoPoint(50.9099, -1.4092));
        }
        else if ((lat>90)||(lat<-90)){
            builder.show();
            mv.getController().setCenter(new GeoPoint(50.9099, -1.4092));
        }
        else{
            mv.getController().setCenter(new GeoPoint(lat,lo));
        }


    }
    protected void onActivityResult(int requestCode,int resultCode,Intent intent)
    {
        if(requestCode==0)
        {
            if (resultCode==RESULT_OK)
            {
                Bundle extras=intent.getExtras();
                boolean cyclemap = extras.getBoolean("com.example.cyclemap");
                double longitude = extras.getDouble("com.example.long");
                double latitude = extras.getDouble("com.example.lat");
                if(cyclemap==true)
                {
                    mv.setTileSource(TileSourceFactory.HIKEBIKEMAP);
                    mv.getController().setCenter(new GeoPoint(latitude,longitude));
                }
                else
                {
                    mv.setTileSource(TileSourceFactory.MAPNIK);
                    mv.getController().setCenter(new GeoPoint(latitude,longitude));
                }
            }
        }
    }


}

